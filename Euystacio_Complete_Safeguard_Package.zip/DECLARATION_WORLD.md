Placeholder for DECLARATION_WORLD.md
Generated safeguard package.
