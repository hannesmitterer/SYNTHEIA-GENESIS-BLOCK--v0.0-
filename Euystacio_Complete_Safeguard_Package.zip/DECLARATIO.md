Placeholder for DECLARATIO.md
Generated safeguard package.
